
package trabalhopoo2;

public class CpfValido extends Exception{
    CpfValido(String msg){
        super(msg);
    }
    
}
