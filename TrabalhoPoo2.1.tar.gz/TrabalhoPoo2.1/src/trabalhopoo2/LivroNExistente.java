
package trabalhopoo2;

public class LivroNExistente extends Exception{
    public LivroNExistente(String msg){
        super (msg);
    }
}
