
package trabalhopoo2;

public  interface InserirListarDeletar {
    void inserir();
    void listar();
    void deletar();
}
